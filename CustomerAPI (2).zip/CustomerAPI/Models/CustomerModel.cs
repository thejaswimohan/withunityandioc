﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomerAPI.Models
{

    using System;
    public class CustomerModel
    {

    }
}