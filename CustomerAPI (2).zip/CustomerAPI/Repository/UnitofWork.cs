﻿

namespace CustomerAPI.Repository
{
    using System;

    public class UnitofWork :  IDisposable
    {
        private CustomerEntities context = new CustomerEntities();

        private CommonRepository<CustomerData> customerRepository;

        private CommonRepository<Admin> adminRepository;
        public CommonRepository<CustomerData> customer_Repository
        {
            get
            {
                if (this.customerRepository == null)
                {
                    this.customerRepository = new CommonRepository<CustomerData>(context);
                }
                return customerRepository;
            }
        }
        public CommonRepository<Admin> admin_Repository
        {
            get
            {
                if (this.adminRepository == null)
                {
                    this.adminRepository = new CommonRepository<Admin>(context);
                }
                return adminRepository;
            }
        }



        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}