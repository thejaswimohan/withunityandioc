﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomerAPI.Repository
{
    public class BasicCustomerRepository:IBasicCustomerRepository
    {
        private CustomerEntities db = new CustomerEntities();

        public BasicCustomerRepository(CustomerEntities db)
        {
            db = new CustomerEntities();
        }
        public IEnumerable<CustomerData> GetEmployees()
        {
            return db.CustomerDatas;
        }
    }
}