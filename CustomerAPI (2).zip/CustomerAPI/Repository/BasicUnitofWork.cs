﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomerAPI.Repository
{
    public class BasicUnitofWork:IUnitofwork
    {
        private readonly CustomerEntities db;

        public BasicUnitofWork()
        {
            db = new CustomerEntities();
        }

        public void Commit()
        {
            db.SaveChanges();
        }

        IBasicCustomerRepository _IBasicCustomerRepository = null;

        public IBasicCustomerRepository Customer
        {
            get
            {
                _IBasicCustomerRepository = new BasicCustomerRepository(db);
                return this.Customer;
            }
        }
    }
}