﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomerAPI.Repository
{
    public interface IUnitofwork 
    {
        IBasicCustomerRepository Customer { get; }

        void Commit();
    }
}